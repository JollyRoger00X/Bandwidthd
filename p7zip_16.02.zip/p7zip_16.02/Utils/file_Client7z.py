
files_c=[
 'C/Threads.c',
]

files_cpp=[
 'CPP/7zip/Common/FileStreams.cpp',
 'CPP/7zip/UI/Client7z/Client7z.cpp',
 'CPP/Common/IntToString.cpp',
 'CPP/Common/MyString.cpp',
 'CPP/Common/MyVector.cpp',
 'CPP/Common/MyWindows.cpp',
 'CPP/Common/StringConvert.cpp',
 'CPP/Common/UTFConvert.cpp',
 'CPP/Common/Wildcard.cpp',
 'CPP/Windows/DLL.cpp',
 'CPP/Windows/FileDir.cpp',
 'CPP/Windows/FileFind.cpp',
 'CPP/Windows/FileIO.cpp',
 'CPP/Windows/FileName.cpp',
 'CPP/Windows/PropVariant.cpp',
 'CPP/Windows/PropVariantConv.cpp',
 'CPP/myWindows/wine_date_and_time.cpp',
]

