/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if you have the `alarm' function. */
#define HAVE_ALARM 1

/* Define if you have the <arpa/inet.h> header file. */
#define HAVE_ARPA_INET_H 1

/* Define if you have the <arpa/nameser.h> header file. */
#define HAVE_ARPA_NAMESER_H 1

/* Define if you have the <dirent.h> header file, and it defines `DIR'. */
#define HAVE_DIRENT_H 1

/* Define if you have the <errno.h> header file. */
#define HAVE_ERRNO_H 1

/* Define if you have the <gdfonts.h> header file. */
#define HAVE_GDFONTS_H 1

/* Define if you have the <gd/gdfonts.h> header file. */
/* #undef HAVE_GD_GDFONTS_H */

/* Define if you have the <gd/gd.h> header file. */
/* #undef HAVE_GD_GD_H */

/* Define if you have the <gd.h> header file. */
#define HAVE_GD_H 1

/* Define if you have the `gethostbyaddr' function. */
#define HAVE_GETHOSTBYADDR 1

/* Define if you have the `inet_ntoa' function. */
#define HAVE_INET_NTOA 1

/* Define if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define if you have the `gd' library (-lgd). */
#define HAVE_LIBGD 1

/* Define if you have the `iconv' library (-liconv). */
/* #undef HAVE_LIBICONV */

/* Define if you have the `m' library (-lm). */
#define HAVE_LIBM 1

/* Define if you have the `nsl' library (-lnsl). */
#define HAVE_LIBNSL 1

/* Define if you have the `pcap' library (-lpcap). */
#define HAVE_LIBPCAP 1

/* Define if you have the `png' library (-lpng). */
#define HAVE_LIBPNG 1

/* Define if you have the `pq' library (-lpq). */
/* #undef HAVE_LIBPQ */

/* Define if you have the `resolv' library (-lresolv). */
#define HAVE_LIBRESOLV 1

/* Define if you have the `socket' library (-lsocket). */
/* #undef HAVE_LIBSOCKET */

/* Define if you have the `wpcap' library (-lwpcap). */
/* #undef HAVE_LIBWPCAP */

/* Define if your system has a working `malloc' function. */
#define HAVE_MALLOC 1

/* Define if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define if you have the `memset' function. */
#define HAVE_MEMSET 1

/* Define if you have the <ndir.h> header file, and it defines `DIR'. */
/* #undef HAVE_NDIR_H */

/* Define if you have the <netdb.h> header file. */
#define HAVE_NETDB_H 1

/* Define if you have the <netinet/in.h> header file. */
#define HAVE_NETINET_IN_H 1

/* Define if you have the `pcap_findalldevs' function. */
#define HAVE_PCAP_FINDALLDEVS 1

/* Define if you have the <pcap.h> header file. */
#define HAVE_PCAP_H 1

/* Define if you have the <resolv.h> header file. */
#define HAVE_RESOLV_H 1

/* Define if `stat' has the bug that it succeeds when given the zero-length
   file name argument. */
/* #undef HAVE_STAT_EMPTY_STRING_BUG */

/* Define if you have the <stddef.h> header file. */
#define HAVE_STDDEF_H 1

/* Define if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define if you have the `strdup' function. */
#define HAVE_STRDUP 1

/* Define if you have the `strftime' function. */
#define HAVE_STRFTIME 1

/* Define if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define if you have the <syslog.h> header file. */
#define HAVE_SYSLOG_H 1

/* Define if you have the <sys/dir.h> header file, and it defines `DIR'. */
/* #undef HAVE_SYS_DIR_H */

/* Define if you have the <sys/ndir.h> header file, and it defines `DIR'. */
/* #undef HAVE_SYS_NDIR_H */

/* Define if you have the <sys/socket.h> header file. */
#define HAVE_SYS_SOCKET_H 1

/* Define if you have the <sys/time.h> header file. */
#define HAVE_SYS_TIME_H 1

/* Define if you have the <sys/wait.h> header file. */
#define HAVE_SYS_WAIT_H 1

/* Define if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define if `lstat' dereferences a symlink specified with a trailing slash.
   */
#define LSTAT_FOLLOWS_SLASHED_SYMLINK 1

/* Define as the return type of signal handlers (`int' or `void'). */
#define RETSIGTYPE void

/* Define if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* dest port field name in tcphdr */
#define TCPHDR_DPORT th_dport

/* source port field name in tcphdr */
#define TCPHDR_SPORT th_sport

/* Define if you can safely include both <sys/time.h> and <time.h>. */
#define TIME_WITH_SYS_TIME 1

/* Define if your <sys/time.h> declares `struct tm'. */
/* #undef TM_IN_SYS_TIME */

/* Define if `lex' declares `yytext' as a `char *' by default, not a `char[]'.
   */
/* #undef YYTEXT_POINTER */

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */

/* Define as `__inline' if that's what the C compiler calls it, or to nothing
   if it is not supported. */
/* #undef inline */

/* Define to `int' if <sys/types.h> does not define. */
/* #undef pid_t */

/* Define to `unsigned' if <sys/types.h> does not define. */
/* #undef size_t */
